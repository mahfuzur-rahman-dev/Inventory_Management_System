﻿
using Microsoft.AspNetCore.Identity;

namespace Inventory.DataAccess.IdentityManager
{
    public class ApplicationIdentityUser : IdentityUser<Guid>
    {
    }
}
