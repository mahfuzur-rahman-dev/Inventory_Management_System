﻿using Inventory.DataAccess.Entites;
using Inventory.DataAccess.Enums;
using Inventory.DataAccess.IdentityManager;
using Inventory.DataAccess.UnitOfWork;
using Inventory.Service.Features.Services.IServices;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Service.Features.Services
{
    public class OrderManagementService : IOrderManagementService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IOrderDetailManagementService _orderDetailManagementService;
        private readonly IProductManagementService _productManagementService;
        public OrderManagementService(IUnitOfWork unitOfWork, IOrderDetailManagementService orderDetailManagementService, IProductManagementService productManagementService)
        {
            _unitOfWork = unitOfWork;
            _orderDetailManagementService = orderDetailManagementService;
            _productManagementService = productManagementService;
        }


        public async Task<IEnumerable<Order>> GetAllOrder()
        {
            return await _unitOfWork.Order.GetAllAsync(includeProperties:"OrderDetails");
        }


        public async Task CreateOrderAsync(List<OrderDetail>? orderDetails, Guid userId, int totalQuantity, decimal totalPrice,string? orderType)
        {
            try
            {
                var order = new Order
                {
                    OrderDate = DateTime.Now,
                    OrderType = orderType,
                    TotalAmount = totalPrice,
                    TotalQuantity = totalQuantity,
                    CustomerId = userId,
                    OrderDetails = orderDetails
                };

                await _unitOfWork.Order.CreateAsync(order);

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            

        }


        public async Task<Order> GetOrderByIdAsync(Guid id)
        {
            return await _unitOfWork.Order.GetAsync(x=>x.Id == id);
        }

        public async Task RemoveOrderAsync(Order order)
        {
            await _unitOfWork.Order.RemoveAsync(order);
        }


        public async Task<IEnumerable<Order>> GetOrderByUserIdAsync(Guid userId)
        {
            return await _unitOfWork.Order.GetAllAsync(x => x.CustomerId == userId, includeProperties: "User,Product");
        }

        public async Task<IEnumerable<OrderDetail>> GetAllOrderDetailsByUserId(Guid userId)
        {
            return await _orderDetailManagementService.GetOrderDetailByUserIdAsync(userId);
        }

        public async Task<IEnumerable<Product>> GetAllProductNameAsync()
        {
            return await _productManagementService.GetAllProducts();
        }

        public async Task CreateSaleOrder(Guid userId,Guid productId, int saleQuantity, decimal unitPrice, decimal totalAmount)
        {
            var saleOrderDetail = await _orderDetailManagementService.AddToOrderDetailForSaleAsync(userId,productId,saleQuantity,unitPrice,totalAmount);

            var order = new Order
            {
                OrderDate = DateTime.Now,
                OrderType = orderType,
                TotalAmount = totalPrice,
                TotalQuantity = totalQuantity,
            };
        }
    }
}
