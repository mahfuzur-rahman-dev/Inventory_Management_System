﻿namespace Inventory.Presentation.Models
{
    public class ViewCartDTO
    {
        public int TotalQuantity { get; set; } 
        public decimal TotalAmount { get; set; }
    }
}
